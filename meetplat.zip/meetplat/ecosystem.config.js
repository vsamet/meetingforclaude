module.exports = {
  apps : [{
    name: 'app.meetplat.com',
    script: 'G:\\web\\meetplat\\app.meetplat.com\\server.js',
    cwd: 'G:\\web\\meetplat\\app.meetplat.com\\',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '300M',
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production'
    }
  }]
};
