# Changelog
MeetPlat Integration Project

## [Unreleased]
- 

## [3.0.0] - 2022-09-01
### Added
- 

### Changed
- 

### Removed
- 

## [2.7.0] - 2021-04-01
### Added
- Design Save And Close Button
- Design Image Object Fit
- Design Text Field
- Panorama Hide Free property

### Changed
- Integration GSuite Fix
- User Role Display (Normal: Display Only Rooms Menu, Admin: All Menus)

### Removed
- 

## [2.6.0] - 2021-03-01
### Added
- Design Analog Clock
- Degign Timeline Band
- IOS iPad Player (https://apps.apple.com/us/app/id1550473324)

### Changed
- Design Opacity for Rectangle and Image
- Tag Select from Display
- Tag Full Screen Image
- Integration server url autofill

### Removed
- 

## [2.5.0] - 2021-02-01
### Added
- Custom Integration

### Changed
- Design Current Meeting Info Split
- Design Image Select Static Image
- Desing Component Add

### Removed
- 

## [2.4.0] - 2021-01-01
### Added
- LDAP Configuration
- Select AD Account 

### Changed
- 

### Removed
- 

## [2.3.0] - 2020-11-01
### Added
- New Client Error Messages (User Name Password, Delegate Error, Mailbox Error, Room Select Player error)
- Panomara timeline 
- Tag Theme
- Tags Managament

### Changed
- DB system change

### Removed
- 

## [2.2.0] - 2020-10-01
### Added
- Panorama weekly list

### Changed
- Design Add Button 15min, 30min, 45min, 60min changed
- Fix, Panorama Locations remove when room save
- Panorama display clock on/off
- Panorama Room Box dynamic size (small, normal, big)
- Room Locations for Find Room
- Panorama hide subject activated

### Removed
- 

## [2.1.3] - 2020-09-01
### Added
- Android door open automation

### Changed
- Android App mac address check code

### Removed
- 

## [2.1.2] - 2020-07-01
### Added
- Master Theme Analog Clock

### Changed
- Weather check if weather widget added

### Removed
- 

## [2.1.1] - 2020-05-01
### Added
- Theme Order
- Drink Type (Hot / Cold)

### Changed
- 

### Removed
- 

## [2.1.0] - 2020-04-01
### Added
- QR Code for Kitchen Order
- Count Down Widget
- Next Meeting List Widget
- SMS Integration
- Room Select within Room List Group
- Attendees Widget
- Room Manager Integration

### Changed
- Light off outside timer

### Removed
- 


## [2.0.0] - 2020-03-01
### Added
- Language sections
- Player restart added
- Assets managament
- Theme Design Editor 
- Weather

### Changed
- Players Room relations show
- Remove room relation for player delete
- Online Offline status fix

### Removed
- 

## [1.8.0] - 2020-02-01
### Added
- MeetPlat Planner service
- NTLM authentication
- Automation Console
- Kitchen Order

### Changed
- General settings Proxy

### Removed
- 

## [1.7.0] - 2020-01-01
### Added
- Message Delay timeout
- Multi language
- Check-In WorkFlow

### Changed
- Keypad fix

### Removed
- 

## [1.6.0] - 2019-12-01
### Added
- Master Theme
- GSuite Service

### Changed
- Preview Fix
- Texts colors
- Panorama room select

### Removed
- 

## [1.5.0] - 2019-11-01
### Added
- Theme Preview

### Changed
- LG Optimization

### Removed
- Splash Screen
- Milimalist Theme
- Split Theme 

## [1.4.0] - 2019-10-01
### Added
- Philips display BDL10 Series

### Changed
- Datetime converted to control

### Removed
- 

## [1.3.0] - 2019-09-01
### Added
- Dibs rooms

### Changed
- License fix

### Removed
- Angular animations

## [1.2.0] - 2019-08-01
### Added
- Meeting End Early 
- Meeting Extend
- Panorama display

### Changed
- 

### Removed
- 

## [1.1.0] - 2019-07-01
### Added
- Auto discovery
- Daily View added

### Changed
- Room Player Select

### Removed
- 

